/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calc;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Calc {

    private static Double num1;
    private static Double num2;
    private static Double result;

    private static String op;

    public static void main(String[] args) {
        JFrame f = new JFrame("Calculator");
        f.setSize(500, 500);

        // Panel for text field
        JPanel p1 = new JPanel();
        p1.setBorder(new EmptyBorder(new Insets(20, 0, 0, 0)));
        final JTextField txt = new JTextField(31);
        txt.setPreferredSize(new Dimension(300, 50));

        txt.setEditable(false);
        p1.add(txt);

        // Panel for buttons
        JPanel p2 = new JPanel(new GridBagLayout());
        p2.setBorder(new EmptyBorder(new Insets(0, 0, 0, 0)));

        // Adding buttons to the panel using GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JButton back = new JButton("BACK");
        JButton ce = new JButton("CE");
        JButton c = new JButton("C");
        JButton plus = new JButton("+");
        back.setPreferredSize(new Dimension(80, 60));
        ce.setPreferredSize(new Dimension(80, 60));
        c.setPreferredSize(new Dimension(80, 60));
        plus.setPreferredSize(new Dimension(80, 60));

        JButton b7 = new JButton("7");
        JButton b8 = new JButton("8");
        JButton b9 = new JButton("9");
        JButton div = new JButton("/");
        b7.setPreferredSize(new Dimension(80, 60));
        b8.setPreferredSize(new Dimension(80, 60));
        b9.setPreferredSize(new Dimension(80, 60));
        div.setPreferredSize(new Dimension(80, 60));

        JButton b4 = new JButton("4");
        JButton b5 = new JButton("5");
        JButton b6 = new JButton("6");
        JButton multi = new JButton("*");
        b4.setPreferredSize(new Dimension(80, 60));
        b5.setPreferredSize(new Dimension(80, 60));
        b6.setPreferredSize(new Dimension(80, 60));
        multi.setPreferredSize(new Dimension(80, 60));

        JButton b1 = new JButton("1");
        JButton b2 = new JButton("2");
        JButton b3 = new JButton("3");
        JButton minus = new JButton("-");
        b1.setPreferredSize(new Dimension(80, 60));
        b2.setPreferredSize(new Dimension(80, 60));
        b3.setPreferredSize(new Dimension(80, 60));
        minus.setPreferredSize(new Dimension(80, 60));

        JButton porm = new JButton("+/-");
        JButton b0 = new JButton("0");
        JButton point = new JButton(".");
        JButton equal = new JButton("=");
        porm.setPreferredSize(new Dimension(80, 60));
        b0.setPreferredSize(new Dimension(80, 60));
        point.setPreferredSize(new Dimension(80, 60));
        equal.setPreferredSize(new Dimension(80, 60));

        // Adding buttons to the panel using GridBagConstraints
        gbc.gridx = 0;
        gbc.gridy = 0;
        p2.add(back, gbc);

        gbc.gridx = 1;
        p2.add(ce, gbc);

        gbc.gridx = 2;
        p2.add(c, gbc);

        gbc.gridx = 3;
        p2.add(plus, gbc);

        ////////////////////////////////////////////////////////////////////////
        gbc.gridx = 0;
        gbc.gridy = 1;
        p2.add(b7, gbc);

        gbc.gridx = 1;
        p2.add(b8, gbc);

        gbc.gridx = 2;
        p2.add(b9, gbc);

        gbc.gridx = 3;
        p2.add(div, gbc);

        //////////////////////////////////////////////////////////////////////////
        gbc.gridx = 0;
        gbc.gridy = 2;
        p2.add(b4, gbc);

        gbc.gridx = 1;
        p2.add(b5, gbc);

        gbc.gridx = 2;
        p2.add(b6, gbc);

        gbc.gridx = 3;
        p2.add(multi, gbc);

        //////////////////////////////////////////////////////////////////////////
        gbc.gridx = 0;
        gbc.gridy = 3;
        p2.add(b1, gbc);

        gbc.gridx = 1;
        p2.add(b2, gbc);

        gbc.gridx = 2;
        p2.add(b3, gbc);

        gbc.gridx = 3;
        p2.add(minus, gbc);

        ///////////////////////////////////////////
        gbc.gridx = 0;
        gbc.gridy = 4;
        p2.add(porm, gbc);

        gbc.gridx = 1;
        p2.add(point, gbc);

        gbc.gridx = 2;
        p2.add(b0, gbc);

        gbc.gridx = 3;
        p2.add(equal, gbc);
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////

        ////action listener
        b7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "7");
            }

        });
        b8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "8");
            }

        });
        b9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "9");
            }

        });
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "4");
            }

        });
        b5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "5");
            }

        });
        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "6");
            }

        });
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "1");
            }

        });
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "2");
            }

        });
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                txt.setText(txt.getText() + "3");
            }

        });
        point.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + ".");
            }

        });

        b0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(txt.getText() + "0");
            }

        });

        back.addActionListener(new ActionListener() {
            @Override

            public void actionPerformed(ActionEvent e) {
                String currentText = txt.getText();
                if (!currentText.isEmpty()) {
                    txt.setText(currentText.substring(0, currentText.length() - 1));
                }
            }

        });

        ce.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText(" ");
            }

        });
        c.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String currentText = txt.getText();
                if (!currentText.isEmpty()) {
                    txt.setText(currentText.substring(0, currentText.length() - 1));
                }
            }
        });

        porm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txt.setText("+/-");
            }

        });

        plus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Double.parseDouble(txt.getText());
                op = "+";
                txt.setText("");

            }
        });
        minus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Double.parseDouble(txt.getText());
                op = "-";
                txt.setText("");

            }
        });
        plus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Double.parseDouble(txt.getText());
                op = "+";
                txt.setText("");

            }
        });

        multi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Double.parseDouble(txt.getText());
                op = "*";
                txt.setText("");
            }
        });
        div.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num1 = Double.parseDouble(txt.getText());
                op = "/";
                txt.setText("");
            }
        });

        equal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                num2 = Double.parseDouble(txt.getText());
                switch (op) {
                    case "+":
                        result = num1 + num2;
                        break;

                }
                switch (op) {
                    case "-":
                        result = num1 - num2;
                        break;

                }
                switch (op) {
                    case "*":
                        result = num1 * num2;
                        break;

                }
                switch (op) {
                    case "/":
                        result = num1 / num2;
                        break;

                }
                txt.setText(String.valueOf(result));
                num1 = result;
            }

        });

        // Adding panels to the frame
        f.add(p1, BorderLayout.NORTH);
        f.add(p2);
        f.setVisible(true);
        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
    }
}
